package HeapMemory;

public class HeapNode {
    int data;
    HeapNode next;

    public HeapNode(){
        this.next = null;
    }
   
    
}
