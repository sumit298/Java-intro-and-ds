public class PhoneBookNode {
    String name;
    long number;
    PhoneBookNode left;
    PhoneBookNode right;

    public PhoneBookNode() {
        this.left = null;
        this.right = null;
    }
}
